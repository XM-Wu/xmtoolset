#version 440
layout(location = 0) in vec3 vWorld;
layout(location = 1) in vec3 vNormal;
layout(location = 2) in vec3 vViewNormal;
layout(location = 3) in vec2 vUv;
layout(location = 0) out vec4 frag;
layout(std140, binding = 0) uniform buf {
    mat4 uMvp;
    mat4 uModel;
    mat4 uNormal;
    mat4 uViewNormal;
    vec4 uCamera;
    vec4 uDiffuse;
    vec4 uParams;
};
layout(binding = 1) uniform sampler2D uTexture;
layout(binding = 2) uniform sampler2D uSphere;

void main()
{
    vec3 n = normalize(vNormal);
    if (!gl_FrontFacing)
        n = -n;
    vec3 viewDir = normalize(uCamera.xyz - vWorld);
    int mode = int(uParams.x + 0.5);
    if (mode == 0) {
        vec4 color = int(uParams.y + 0.5) == 1 ? texture(uTexture, vUv) : vec4(1.0);
        float cutoff = max(uParams.w, 0.02);
        if (color.a < cutoff)
            discard;
        if (cutoff >= 0.49)
            color.a = 1.0;
        frag = color;
        return;
    }
    if (mode == 1) {
        vec3 l1 = normalize(vec3(0.42, 0.78, 0.46));
        vec3 l2 = normalize(vec3(-0.62, 0.22, 0.28));
        float key = max(dot(n, l1), 0.0);
        float fill = max(dot(n, l2), 0.0);
        float wrap = key * 0.72 + fill * 0.22 + 0.18;
        vec3 lit = mix(vec3(0.22, 0.24, 0.28), vec3(0.80, 0.81, 0.84), clamp(wrap, 0.0, 1.0));
        float rim = pow(1.0 - max(dot(n, viewDir), 0.0), 2.8) * 0.18;
        frag = vec4(lit + vec3(rim), 1.0);
        return;
    }
    vec4 color = uDiffuse;
    if (int(uParams.y + 0.5) == 1)
        color *= texture(uTexture, vUv);
    int sphereMode = int(uParams.z + 0.5);
    if (sphereMode == 1 || sphereMode == 2) {
        vec3 vn = normalize(vViewNormal);
        if (!gl_FrontFacing)
            vn = -vn;
        vec2 sph = vn.xy * 0.5 + 0.5;
        vec3 sphc = texture(uSphere, sph).rgb;
        if (sphereMode == 1)
            color.rgb *= sphc;
        else
            color.rgb += sphc;
    }
    float cutoff = max(uParams.w, 0.02);
    if (color.a < cutoff)
        discard;
    if (cutoff >= 0.49)
        color.a = 1.0;
    frag = color;
}
