#version 440
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUv;
layout(location = 0) out vec3 vWorld;
layout(location = 1) out vec3 vNormal;
layout(location = 2) out vec3 vViewNormal;
layout(location = 3) out vec2 vUv;
layout(std140, binding = 0) uniform buf {
    mat4 uMvp;
    mat4 uModel;
    mat4 uNormal;
    mat4 uViewNormal;
    vec4 uCamera;
    vec4 uDiffuse;
    vec4 uParams;
};

void main()
{
    vec4 world = uModel * vec4(aPos, 1.0);
    vWorld = world.xyz;
    vNormal = normalize(mat3(uNormal) * aNormal);
    vViewNormal = normalize(mat3(uViewNormal) * aNormal);
    vUv = aUv;
    gl_Position = uMvp * vec4(aPos, 1.0);
}
