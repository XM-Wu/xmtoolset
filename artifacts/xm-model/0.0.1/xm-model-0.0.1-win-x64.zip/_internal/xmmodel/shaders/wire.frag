#version 440
layout(location = 0) out vec4 frag;
layout(std140, binding = 0) uniform buf {
    mat4 uMvp;
    vec4 uColor;
};

void main()
{
    frag = uColor;
}
