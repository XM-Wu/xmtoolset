#version 440
layout(location = 0) in vec3 aPos;
layout(std140, binding = 0) uniform buf {
    mat4 uMvp;
    vec4 uColor;
};

void main()
{
    gl_Position = uMvp * vec4(aPos, 1.0);
}
